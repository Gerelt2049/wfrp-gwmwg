# WFRP - Gerwin Waffenhalter’s Magnificent Weapons Gallery
Adds new weapons and weapon traits from the Ratter Vol. 1 Issue 2. Requires the WFRP 4e system.
## Links:
* Manifest: https://raw.githubusercontent.com/DasSauerkraut/wfrp-gwmwg/master/module.json
* Direct Link: https://github.com/DasSauerkraut/wfrp-gwmwg/raw/master/package/wfrp-gwmwg-v1.0.0.zip

This module **REQUIRES** the [WFRP4e](https://gitlab.com/tposney/about-time) system installed and loaded to function correctly.

This module adds the 'Slashing' weapon quality as well as the expanded weapons form [The Ratter Vol. 1 Issue 2](https://indd.adobe.com/view/763c1883-228a-455f-a115-19f4059f4589)
